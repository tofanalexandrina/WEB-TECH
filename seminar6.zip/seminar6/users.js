const users=[
    {id:1, name:'Adrian', age:30},
    {id:2, name:'Mihai', age:25},
    {id:3, name:'Adrian', age:26}
]
module.exports=users;