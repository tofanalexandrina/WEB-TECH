export const number=34;
//module.exports(number);